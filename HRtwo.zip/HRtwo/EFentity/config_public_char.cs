
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFentity
{
   public class config_public_char
    {
        public System.Int16 Id { get; set; }
   
                         
        public System.String attribute_kind { get; set; }
   
                         
        public System.String attribute_name { get; set; }
   
                         }}
