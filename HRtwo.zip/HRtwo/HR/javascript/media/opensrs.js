<!--
function prepareSeal()
{
window.open('','srsSeal','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=630,height=350');
}
//-->