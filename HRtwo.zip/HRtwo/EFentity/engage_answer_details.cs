
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFentity
{
   public class engage_answer_details
    {
        public System.Int16 Id { get; set; }
   
                         
        public System.String answer_number { get; set; }
   
                         
        public System.Int16 subject_id { get; set; }
   
                         
        public System.String answer { get; set; }
   
                         }}
