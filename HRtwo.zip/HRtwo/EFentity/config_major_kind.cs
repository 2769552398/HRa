
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFentity
{
   public class config_major_kind
    {
        public System.Int16 Id { get; set; }
   
                         
        public System.String major_kind_id { get; set; }
   
                         
        public System.String major_kind_name { get; set; }
   
                         }}
