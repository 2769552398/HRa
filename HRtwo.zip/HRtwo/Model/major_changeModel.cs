using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class major_changeModel
    {
        public System.Int16 Id { get; set; }
        public System.String first_kind_id { get; set; }
        public System.String first_kind_name { get; set; }
        public System.String second_kind_id { get; set; }
        public System.String second_kind_name { get; set; }
        public System.String third_kind_id { get; set; }
        public System.String third_kind_name { get; set; }
        public System.String major_kind_id { get; set; }
        public System.String major_kind_name { get; set; }
        public System.String major_id { get; set; }
        public System.String major_name { get; set; }
        public System.String new_first_kind_id { get; set; }
        public System.String new_first_kind_name { get; set; }
        public System.String new_second_kind_id { get; set; }
        public System.String new_second_kind_name { get; set; }
        public System.String new_third_kind_id { get; set; }
        public System.String new_third_kind_name { get; set; }
        public System.String new_major_kind_id { get; set; }
        public System.String new_major_kind_name { get; set; }
        public System.String new_major_id { get; set; }
        public System.String new_major_name { get; set; }
        public System.String human_id { get; set; }
        public System.String human_name { get; set; }
        public System.String salary_standard_id { get; set; }
        public System.String salary_standard_name { get; set; }
        public System.Decimal salary_sum { get; set; }
        public System.String new_salary_standard_id { get; set; }
        public System.String new_salary_standard_name { get; set; }
        public System.Decimal new_salary_sum { get; set; }
        public System.String change_reason { get; set; }
        public System.String check_reason { get; set; }
        public System.Int16 check_status { get; set; }
        public System.String register { get; set; }
        public System.String checker { get; set; }
        public System.DateTime regist_time { get; set; }
        public System.DateTime check_time { get; set; }
    }
}
