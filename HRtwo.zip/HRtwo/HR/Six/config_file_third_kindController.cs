﻿using IBLL;
using IOC;
using Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HR.Six
{

    /// <summary>
    /// 三级机构设置   
    /// </summary>
    public class config_file_third_kindController : Controller
    {

        Iconfig_file_third_kindBLL ibll = IocCreat.Createeconfig_file_third_kindBLL();
      

        //首页
        public ActionResult third_kind()
        {
            return View();
        }

        //查询全部
        public ActionResult Select()
        {
            List<config_file_third_kindModel> list = ibll.Select();
            return Content(JsonConvert.SerializeObject(list));
        }


       //新增
        public ActionResult Create()
        {
            return View();
        }

        // POST: config_file_third_kind/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        //修改显示
        // GET: config_file_third_kind/Edit/5
        public ActionResult third_kind_change(int id)
        {
            return View();
        }

        //修改
        [HttpPost]
        public ActionResult third_kind_change(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: config_file_third_kind/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: config_file_third_kind/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
