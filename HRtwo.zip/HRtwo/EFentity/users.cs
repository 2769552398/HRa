
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFentity
{
   public class users
    {
        public System.Int16 Id { get; set; }
   
                         
        public System.String u_name { get; set; }
   
                         
        public System.String u_true_name { get; set; }
   
                         
        public System.String u_password { get; set; }
   
                         }}
