
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFentity
{
   public class config_primary_key
    {
        public System.Int16 Id { get; set; }
   
                         
        public System.String primary_key_table { get; set; }
   
                         
        public System.String primary_key { get; set; }
   
                         
        public System.String key_name { get; set; }
   
                         
        public System.Boolean primary_key_status { get; set; }
   
                         }}
